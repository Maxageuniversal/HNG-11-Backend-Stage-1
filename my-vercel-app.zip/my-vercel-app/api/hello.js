const express = require('express');
const app = express();

app.get('/api/hello', (req, res) => {
    const visitorName = req.query.visitor_name || 'Guest';
    const clientIp = req.headers['x-forwarded-for'] || req.connection.remoteAddress || '127.0.0.1';
    const location = 'New York'; // Hardcoded location for demonstration

    const greeting = `Hello, ${visitorName}! The temperature is 11 degrees Celsius in ${location}.`;

    res.json({
        client_ip: clientIp,
        location,
        greeting
    });
});

module.exports = app;
